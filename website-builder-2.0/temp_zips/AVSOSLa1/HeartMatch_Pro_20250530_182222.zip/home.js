document.querySelector('button').addEventListener('click', () => {
  window.location.href = 'test.html'; //  替换 'test.html' 为你的测试页面的文件名
});